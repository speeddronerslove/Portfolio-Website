# MOGANA MURALI PORTFOLIO — MASTER DESIGN BIBLE V1.0

## PROJECT GOAL

Create a cinematic, single-page portfolio experience.

This is NOT a developer portfolio template.

This is NOT a startup landing page.

This is NOT an agency website.

This is a personal digital experience that gradually reveals the person behind the work.

The visitor should discover information naturally while scrolling.

The website must feel memorable, intentional, premium, and cinematic.

---

## CORE EXPERIENCE

The website should create the following journey:

Who is this person?

↓

This is interesting.

↓

Wait, he did that?

↓

He does that too?

↓

This person has range.

The website should reveal information.

It should never dump information.

---

## WEBSITE STRUCTURE

Single Page Application

No separate pages.

No routing.

No About page.

No Skills page.

No Projects page.

No Achievement page.

Everything exists within one continuous scrolling experience.

Each section should feel like a new scene.

Not a new page.

---

## PRIMARY REFERENCES

40% GTA 6 Website

40% Sidd Ahmed Portfolio

20% Original Personal Identity

Do NOT copy layouts.

Only borrow the feeling.

---

## VISUAL IDENTITY

Style:
Editorial
Cinematic
Modern
Premium
Minimal

Mood:
Confident
Intentional
Curious

Avoid:
Corporate
Startup
Agency
Cyberpunk
Gamer Website
Developer Template

---

## COLOR SYSTEM

Background:
#000000
#050505

Primary Text:
#FFFFFF

Secondary Text:
#9A9A9A

Accent Gradient:
#FF7A00
#FF5A00
#E64500
#2A0000

IMPORTANT:

Orange is not a theme color.

Orange behaves like a light source.

Use gradients as atmosphere.

Never paint the entire website orange.

---

## TYPOGRAPHY

Typography is a major design element.

Large headings.

Bold.

Confident.

Strong hierarchy.

Examples:

MOGANA MURALI

JOURNEY

WORK

MILESTONES

FUTURE

Typography should often be larger than expected.

---

## SPACING

Large breathing room.

Generous vertical spacing.

Premium layouts.

Never compress sections together.

The website should feel calm and deliberate.

---

## LAYOUT RULES

One idea per section.

Never combine:

About
Skills
Projects
Achievements

inside the same section.

Each section should communicate one purpose only.

---

## CONTENT REVEAL ORDER

Scene 1
Arrival

Scene 2
Identity

Scene 3
Journey

Scene 4
Milestones

Scene 5
Work

Scene 6
Creative Side

Scene 7
Future

Scene 8
Contact

Information should unfold naturally.

---

## ANIMATION SYSTEM

Allowed:

Fade In

Reveal On Scroll

Slow Parallax

Image Expansion

Text Reveal

Opacity Transitions

Section Blending

Forbidden:

Typing Effects

Bouncing Elements

Floating Icons

Rotating Logos

Excessive Motion

Fast Animations

Animation should feel cinematic.

Not playful.

---

## CARD DESIGN

Minimal usage.

Avoid traditional portfolio cards.

If cards are needed:

Background:
rgba(255,255,255,0.03)

Border:
rgba(255,255,255,0.08)

Border Radius:
32px

Large padding.

---

## IMAGERY

Large visuals.

Full-width imagery when appropriate.

Editorial composition.

Avoid tiny thumbnails.

Avoid crowded galleries.

Images should feel important.

---

## NAVIGATION

Minimal.

Simple.

Clean.

Navigation exists to guide.

Not to dominate.

---

## SECTION TRANSITIONS

Bad:

Hero

---

About

---

Projects

Good:

Hero fades

↓

Gradient expands

↓

New scene emerges

↓

Content reveals

↓

Next scene grows naturally

Sections should blend together.

---

## CONTENT PHILOSOPHY

Do not introduce coding immediately.

Do not introduce gaming immediately.

Do not introduce technologies immediately.

Do not introduce achievements immediately.

Allow visitors to discover them gradually.

Every reveal should feel earned.

---

## FORBIDDEN ELEMENTS

Skill Bars

Circular Progress Indicators

Percentage Meters

Tech Stack Grids

Generic Service Cards

Developer Portfolio Templates

Glassmorphism

Neon Effects

Typing Animations

Floating Social Icons Everywhere

Statistics Counters Without Purpose

Generic Hero Sections

"Hi, I'm a passionate developer"

Any cliché portfolio content

---

## DEVELOPMENT STACK

React

Vite

Tailwind CSS

Framer Motion

Responsive Design

Desktop First

Mobile Optimized

---

## RULE FOR ALL AI MODELS

When generating any section:

Do not introduce new colors.

Do not introduce new typography systems.

Do not introduce new spacing systems.

Do not introduce new visual styles.

Do not redesign the website.

Only build the requested section while following this Design Bible exactly.

Maintain consistency with the overall cinematic experience.